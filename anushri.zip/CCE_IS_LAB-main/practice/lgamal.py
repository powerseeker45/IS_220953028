from Crypto.Util.number import getPrime, inverse, bytes_to_long, long_to_bytes
from Crypto.Random import random

def generate_keys():
    p = 7919
    g = 2
    h = 6465  
    x=2999
    return (p, g, h), x

def elgamal_encrypt(public_key, message):
    p, g, h = public_key
    k = 4  
    c1 = pow(g, k, p)  
    m = bytes_to_long(message)
    c2 = (m * pow(h, k, p)) % p  
    return c1, c2

def elgamal_decrypt(private_key, p, c1, c2):
    x = private_key
    s = pow(c1, x, p) 
    s_inv = inverse(s, p) 
    m = (c2 * s_inv) % p 
    return long_to_bytes(m)

public_key, private_key = generate_keys()
message = b"Asymmetric Algorithms"

ciphertext = elgamal_encrypt(public_key, message)
print("Ciphertext:", ciphertext)

decrypted_message = elgamal_decrypt(private_key, public_key[0], ciphertext[0], ciphertext[1])
print("Decrypted message:", decrypted_message.decode())